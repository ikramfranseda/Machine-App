windows (vscode)
python -m pip install streamlit
python -m pip install scikit-learn
python -m pip install pandas numpy matplotlib seaborn scikit-learn streamlit
run :
python -m streamlit run app.py

gcollab :
!pip install streamlit
!npm install localtunnel
!streamlit run app.py & npx localtunnel --port 8501
run :
streamlit run app.py


Silhouette Score Semakin bagus jika Nilainya semakin besar
DB-Index Semakin bagus jika Nilainya semakin kecil
Secara metrik, nilai Silhouette Score dan Davies–Bouldin Index menunjukkan bahwa pemilihan jumlah cluster K = 4 memberikan kualitas pemisahan cluster terbaik dibandingkan nilai K lainnya.